from sqlmodel import SQLModel, Field

class Closed_days(SQLModel, table=True):
    c_code : int = Field(
        primary_key=True
    )
    dow : str